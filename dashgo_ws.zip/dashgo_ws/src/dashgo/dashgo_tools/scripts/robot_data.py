#!/usr/bin/env python  
#coding=utf-8  
from pyc import RobotData

if __name__ == '__main__':
  RobotData.RobotDataTask()
