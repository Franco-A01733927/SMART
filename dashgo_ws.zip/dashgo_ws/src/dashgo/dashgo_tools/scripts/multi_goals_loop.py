#!/usr/bin/env python
#coding=utf-8
from pyc import Multi_goals_loop

if __name__ == '__main__':
  Multi_goals_loop.Multi_goals_loop()
