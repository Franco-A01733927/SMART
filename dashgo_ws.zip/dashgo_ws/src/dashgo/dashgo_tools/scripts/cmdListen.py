#!/usr/bin/env python  
#coding=utf-8  
from pyc import CmdListen

if __name__ == '__main__':
  CmdListen.CmdListen()

