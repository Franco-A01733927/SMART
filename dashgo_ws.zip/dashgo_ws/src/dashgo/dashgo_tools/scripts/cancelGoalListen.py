#!/usr/bin/env python  
#coding=utf-8  
import rospy
from pyc import CancelGoalListen

if __name__ == '__main__':
  CancelGoalListen.CancelGoalListen()




